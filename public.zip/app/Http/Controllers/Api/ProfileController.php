<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage; // 1. Diperlukan untuk mengelola file (foto)
use Illuminate\Validation\Rule; // 2. Diperlukan untuk validasi email unik

class ProfileController extends Controller
{
    /**
     * Menampilkan data user yang sedang login.
     * (Dipanggil oleh: GET /api/profile)
     */
    public function show(Request $request)
    {
        // $request->user() akan otomatis mengambil user
        // yang terotentikasi berdasarkan token Bearer
        return response()->json($request->user());
    }

    /**
     * Memperbarui data user (nama, email, telepon, alamat, dan foto).
     * (Dipanggil oleh: POST /api/profile)
     * * CATATAN: Frontend (ProfilePengguna.vue) harus mengirim ini
     * sebagai 'form-data', bukan 'json'.
     */
    public function update(Request $request)
    {
        // 1. Ambil user yang sedang login
        $user = $request->user();

        // 2. Validasi semua input dari form
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'email' => [
                'required',
                'string',
                'email',
                'max:255',
                // Pastikan email unik, KECUALI untuk user ini sendiri
                Rule::unique('users')->ignore($user->id),
            ],
            'telepon' => 'nullable|string|max:20',
            'alamat' => 'nullable|string',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Validasi foto
        ]);

        // 3. Handle file upload (jika user mengupload foto baru)
        if ($request->hasFile('image')) {
            // Hapus foto profil lama jika ada
            if ($user->profile_photo_path) {
                Storage::delete($user->profile_photo_path);
            }

            // Simpan foto baru di 'storage/app/public/profile_photos'
            $path = $request->file('image')->store('public/profile_photos');

            // Simpan path-nya ke database
            $user->profile_photo_path = $path;
        }

        // 4. Update data user dengan data yang divalidasi
        $user->name = $validatedData['name'];
        $user->email = $validatedData['email'];
        $user->telepon = $validatedData['telepon'];
        $user->alamat = $validatedData['alamat'];

        // 5. Simpan semua perubahan ke database
        $user->save();

        // 6. Kembalikan data user yang sudah diupdate ke frontend
        return response()->json([
            'message' => 'Profil berhasil diperbarui!',
            'user' => $user // 'user' ini akan berisi 'profile_photo_url' yang baru
        ]);
    }

    /* CATATAN:
    Fungsi untuk Ganti Password (dengan password lama)
    sebaiknya dibuat di method terpisah, misalnya 'changePassword()'.
    Method 'update()' ini khusus untuk form edit profil.
    */
}
