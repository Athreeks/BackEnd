<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use App\Models\Cart;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Midtrans\Config; // Untuk Payment Gateway
use Midtrans\CoreApi; // Untuk Payment Gateway

class OrderController extends Controller
{
    /**
     * Menampilkan daftar pesanan.
     * Admin melihat semua; Customer hanya melihat miliknya.
     */
    public function index()
    {
        $user = Auth::user();

        if ($user->role === 'admin') {
            // Jika admin, tampilkan semua pesanan dengan data user & produknya
            $orders = Order::with(['user', 'product'])->latest()->get();
        } else {
            // Jika customer, tampilkan hanya pesanan miliknya
            $orders = Order::where('user_id', $user->id)->with('product')->latest()->get();
        }

        return response()->json($orders);
    }

    /**
     * Menyimpan pesanan baru (langsung, tanpa keranjang).
     * Ini adalah method dari 'apiResource'.
     */
    public function store(Request $request)
    {
        // 1. Validasi input
        $request->validate([
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1',
        ]);

        // 2. Ambil produk dari database
        $product = Product::find($request->product_id);

        // 3. Ambil user yang sedang login
        $user = Auth::user();

        // 4. Hitung total harga
        $totalPrice = $product->price * $request->quantity;

        // 5. Buat pesanan baru
        $order = Order::create([
            'user_id' => $user->id,
            'product_id' => $product->id,
            'quantity' => $request->quantity,
            'total_price' => $totalPrice,
            'status' => 'pending', // Status default
        ]);

        // 6. Kembalikan response
        return response()->json([
            'message' => 'Pesanan berhasil dibuat!',
            'order' => $order,
        ], 201);
    }

    /**
     * Menampilkan detail satu pesanan.
     */
    public function show(Order $order)
    {
        // Pastikan customer hanya bisa melihat order miliknya, admin bisa lihat semua
        if (Auth::id() !== $order->user_id && Auth::user()->role !== 'admin') {
            return response()->json(['message' => 'Akses ditolak'], 403);
        }

        return response()->json($order->load(['user', 'product']));
    }

    /**
     * Update pesanan (Hanya status oleh Admin).
     */
    public function update(Request $request, Order $order)
    {
        // Logika ini HANYA untuk admin
        if (Auth::user()->role !== 'admin') {
            return response()->json(['message' => 'Akses ditolak. Hanya untuk Admin.'], 403);
        }

        $request->validate([
            'status' => 'required|in:pending,paid,completed',
        ]);

        $order->update(['status' => $request->status]);

        return response()->json([
            'message' => 'Status pesanan berhasil diperbarui!',
            'order' => $order,
        ]);
    }

    /**
     * Menghapus/Membatalkan pesanan.
     */
    public function destroy(Order $order)
    {
        // Pastikan hanya user yang bersangkutan atau admin yang bisa menghapus
        if (Auth::id() !== $order->user_id && Auth::user()->role !== 'admin') {
            return response()->json(['message' => 'Akses ditolak'], 403);
        }

        $order->delete();

        return response()->json(['message' => 'Pesanan berhasil dibatalkan'], 200);
    }

    // --- METHOD KUSTOM UNTUK RIWAYAT & PESANAN AKTIF ---

    /**
     * Menampilkan pesanan yang masih aktif (pending/paid).
     */
    public function getActiveOrders()
    {
        $user = Auth::user();
        $query = Order::where('status', '!=', 'completed');

        if ($user->role === 'admin') {
            $orders = $query->with(['user', 'product'])->latest()->get();
        } else {
            $orders = $query->where('user_id', $user->id)->with('product')->latest()->get();
        }

        return response()->json($orders);
    }

    /**
     * Menampilkan riwayat pesanan yang sudah selesai (completed).
     */
    public function getHistoryOrders()
    {
        $user = Auth::user();
        $query = Order::where('status', 'completed');

        if ($user->role === 'admin') {
            $orders = $query->with(['user', 'product'])->latest()->get();
        } else {
            $orders = $query->where('user_id', $user->id)->with('product')->latest()->get();
        }

        return response()->json($orders);
    }

    // --- METHOD KUSTOM UNTUK CHECKOUT & PEMBAYARAN ---

    /**
     * Memproses checkout dari keranjang ke pesanan.
     * Versi ini hanya me-checkout item yang dipilih.
     */
    public function checkout(Request $request)
    {
        // 1. Validasi
        $validatedData = $request->validate([
            'cart_ids' => 'required|array',
            'cart_ids.*' => 'exists:carts,id',
        ]);

        $user = Auth::user();
        $cartIds = $validatedData['cart_ids'];

        // 2. Ambil item keranjang & hitung grand total
        $cartItems = Cart::where('user_id', $user->id)
                        ->whereIn('id', $cartIds)
                        ->with('product')
                        ->get();

        if ($cartItems->isEmpty()) {
            return response()->json(['message' => 'Item keranjang tidak ditemukan.'], 400);
        }

        // Hitung total dari semua item
        $grandTotal = $cartItems->sum(function ($item) {
            return $item->product->price * $item->quantity;
        });

        // 3. Konfigurasi Midtrans
        Config::$serverKey = config('services.midtrans.serverKey');
        Config::$isProduction = config('services.midtrans.isProduction');
        Config::$isSanitized = true;
        Config::$is3ds = false;

        // 4. Buat 1 ID Transaksi unik untuk grup pesanan ini
        $transactionId = 'ORDER-' . $user->id . '-' . time();

        $transactionParams = [
            'payment_type' => 'qris',
            'transaction_details' => [
                'order_id' => $transactionId, // Pakai ID unik ini
                'gross_amount' => $grandTotal,
            ],
            'customer_details' => [
                'first_name' => $user->name,
                'email' => $user->email,
            ],
        ];

        try {
            // 5. Kirim request ke Midtrans
            $payment = CoreApi::charge($transactionParams);
            $qrisUrl = $payment->actions[0]->url;
            $pgTransactionId = $payment->transaction_id; // ID dari Midtrans

            // 6. Mulai Database Transaction
            DB::beginTransaction();

            $createdOrders = [];
            foreach ($cartItems as $item) {
                // 7. Buat entri pesanan untuk setiap item
                $order = Order::create([
                    'user_id' => $user->id,
                    'product_id' => $item->product_id,
                    'quantity' => $item->quantity,
                    'total_price' => $item->product->price * $item->quantity,
                    'status' => 'pending',
                    // Simpan info pembayaran di SETIAP order
                    'pg_transaction_id' => $pgTransactionId,
                    'qris_data_url' => $qrisUrl,
                ]);
                $createdOrders[] = $order;
            }

            // 8. Hapus item dari keranjang
            Cart::where('user_id', $user->id)->whereIn('id', $cartIds)->delete();

            // 9. Konfirmasi transaksi DB
            DB::commit();

            // 10. Kembalikan URL QRIS dan total ke frontend
            return response()->json([
                'message' => 'Checkout berhasil! Silakan selesaikan pembayaran.',
                'orders' => $createdOrders,
                'qris_url' => $qrisUrl,
                'total' => $grandTotal,
            ], 201);

        } catch (\Exception $e) {
            // 8. Jika ada error, batalkan semua
            DB::rollBack();
            return response()->json(['message' => 'Gagal membuat pembayaran.', 'error' => $e->getMessage()], 500);
        }
    }
}
